class Estudiante < ApplicationRecord
end
