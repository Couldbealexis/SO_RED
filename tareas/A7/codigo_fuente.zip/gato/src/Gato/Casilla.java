package Gato;

import javax.swing.JButton;


public class Casilla {
    JButton A;
    int B;
    Casilla()
    {
        A=new JButton();
        B=0;
    }    
}
