from django.apps import AppConfig


class GestionacademicaConfig(AppConfig):
    name = 'GestionAcademica'
