package punto_venta;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexion {
	public Conexion(){
    }
    

	public static final String usuario ="root";
	public static final  String pwd = "";
	public static String bd="ventas";
	public static String url="jdbc:mysql://localhost/ventas";
	 public static Connection conn= null;

	public static Connection getQuey(String query){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			conn = (Connection)DriverManager.getConnection(url, usuario, pwd);
			if(conn != null){
				System.out.println("CONECCION A LA BASE DE DATOS"+url+"...OK");
			}
		}
	     catch (SQLException ex) {
			// TODO Auto-generated catch block
			System.out.println("HUBO PROBLEMA AL CONECTARSE A LA BASE DE DATOS"+url+ex);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();}
		return conn;
		}
	
	
	
	 public ResultSet getQuery(String _query)
	 {
	    Statement state = null;
	    ResultSet resultado = null;
	    try{
	      state = (Statement) conn.createStatement();
	      resultado = state.executeQuery(_query);
	    }
	    catch(SQLException e)
	    {
	      e.printStackTrace();
	    }
	    return resultado;
	 }
	 
	 public void setQuery(String _query){

	    Statement state = null;
	  
	    try{   
	      state=(Statement) conn.createStatement();
	      state.execute(_query);

	    }catch (SQLException e){
	      e.printStackTrace();
	    }
	 }

	 }
	 
	 