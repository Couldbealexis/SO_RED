package punto_venta;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.Set;

import com.mysql.jdbc.PreparedStatement;

public class Main {
	
	public static void main(String[] args)
	{
	    
		Main main = new Main();
		main.menu();
	  
	 }  
	public void menu()
	{
		int opcmenu=0;
		do{
		Main m = new Main();
		Scanner entrada = new Scanner (System.in);
		System.out.println("0) SALIR\n");
		System.out.println("1) Agregar a carrito \n");
		System.out.println("2) Mostrar inventario \n");
		System.out.println("3) Agregar Inventario\n");
		System.out.println("4) Terminar venta\n");
		opcmenu=entrada.nextByte();

		
		
			switch(opcmenu)
			{
			case 1:
				m.insertar_venta();
				int opcion =1;
				int bandera =0;
				do{
					if(bandera ==0 |opcion !=0)
					{
						m.insertar_compra();
						bandera =1;
					}
					if (bandera!= 0)
					{
						System.out.println("Deseas a�adir mas productos?  --SI=1-- NO=0--");
						opcion=entrada.nextByte();
					}
					
				}while(opcion!=0);
				break;
			case 2:
				m.mostrar_inventario();
				try{
					Thread.sleep(5000);
					}catch(InterruptedException e ) { 
					}
				System.out.flush();
				break;
			case 3:
				m.a�adir_inventario();
				System.out.flush();
				break;
			case 4:
				m.terminar_compra();
				break;
			case 0:
				System.out.println("Saliendo");
				break;
			default:
				System.out.println("Valor no valido");
				break;
				
			}
			
		}while(opcmenu != 0);
			
				
	}
	
	
	public void coneccion()
	{
		Conexion conexion = new Conexion();
		   Connection resultado;
		   resultado=Conexion.getQuey(" ");	
	}
	
	public void mostrar_inventario()
	{
		Conexion conexion = new Conexion();
		Connection resultado;
		resultado=Conexion.getQuey(" ");	
	
		ResultSet resultado1;
	    String nombre_producto;
	    String stock,costo;
	    resultado1 = conexion.getQuery("select * from inventario");
	    System.out.println("Inventario en existencia: ");
	  
	    try {
	      while(resultado1.next()){
	      nombre_producto = resultado1.getString("nombre_producto");
	      stock= resultado1.getString("stock");
	     
	      System.out.println("Producto:"+nombre_producto+"--"+"Stock:"+stock);
	      }
	    }catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}
	}
	
	
	public int insertar_venta()
	{
		
	    Connection con = null;
	    con = Conexion.getQuey("");
	    int status=0;
	    try {
			java.sql.PreparedStatement ps=con.prepareStatement(
                    "insert into venta (id_venta, total) values (?, ?)"); 
			 ps.setString(1,  null);
			 ps.setString(2, null);
			 
			 status=ps.executeUpdate();  

		        con.close(); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    	return status;
	}
	
	public void insertar_compra()
	{
		
		Main m = new Main();
		
		Conexion conexion = new Conexion();
		Connection resultado;
		resultado=Conexion.getQuey(" ");	
	    int bandera=0;
		ResultSet resultado1;
	    String id_venta = null;
	    String total;
	    
	    resultado1 = conexion.getQuery("select * from venta");
	  
	  
	    try {
	      while(resultado1.next()&&bandera ==0){
	      id_venta = resultado1.getString("id_venta");
	      total= resultado1.getString("total");
	     bandera++;
	      }
	    }catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}
		
       Scanner lector = new Scanner(System.in);
       
        String nombre_producto =null;
        String costo = null;
    
        System.out.println("Captura el nombre del producto:");
        nombre_producto = lector.next();
        System.out.println("Captura el precio del producto");
        costo = lector.next();
        
       
        try {
			java.sql.PreparedStatement
			ps=resultado.prepareStatement("INSERT INTO producto(nombre_producto,costo,id_venta) values (?, ?,?)");
			 ps.setString(1,  nombre_producto);
			 ps.setString(2, costo);
			ps.setString(3, id_venta);
			 
			ps.execute();
			ps.close();
        } catch (SQLException e ) {
        	if (e.getErrorCode() == 1062)
        	{
        		
        		System.out.println(nombre_producto+"ya existente");
        		//a�adir clase menu
        		
        	}
        		e.printStackTrace();
		}
		
	}
	public void a�adir_inventario()
	{
		
		Connection con = null;
	    con = Conexion.getQuey("");
		Main m = new Main();
		m.mostrar_inventario();
        Scanner lector = new Scanner(System.in);
        
        String nombre_producto =null;
        String stock = null;
    
        System.out.println("Captura el nombre del producto:");
        nombre_producto = lector.next();
        System.out.println("Captura el stock del producto");
        stock = lector.next();
        
        
        try {
			java.sql.PreparedStatement
			ps=con.prepareStatement("INSERT INTO inventario(nombre_producto,stock) values (?, ?)");
			 ps.setString(1,  nombre_producto);
			 ps.setString(2, stock);
			 
			ps.execute();
			ps.close();
        } catch (SQLException e ) {
        	if (e.getErrorCode() == 1062)
        	{
        		
        		System.out.println(nombre_producto+"ya existente en el inventario");
        		m.menu();
        		
        	}
        		e.printStackTrace();
		}

		
	}
	public void terminar_compra()
	{
       Main m = new Main();
		Conexion conexion = new Conexion();
		Connection resultado;
		resultado=Conexion.getQuey(" ");	
	    int bandera=0;
		ResultSet resultado1;
	    String id_venta = null;
	    String total;
	    ResultSet aux;
	    
	    resultado1 = conexion.getQuery("select * from venta");
	  
	  
	    try {
	      while(resultado1.next()&&bandera ==0){
	      id_venta = resultado1.getString("id_venta");
	      total= resultado1.getString("total");
	     bandera++;
	      }
	    }catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}
	    int auxiliar;
	    int auxiliar2;
	    String aux2;
	    aux=conexion.getQuery("select sum(costo)from producto");
	   aux2= aux.toString();
	   String micadena;
	   auxiliar=aux2.indexOf("@");
	   auxiliar2=aux2.indexOf("f");
	   micadena=aux2.substring(auxiliar+1, auxiliar2);
	   System.out.println("Numero de la venta: "+id_venta+"----"+"Total de la compra: "+micadena+"pesos");
	   try{
		   Thread.sleep(3000);
		   }catch(InterruptedException e ) { 
		   }
	 
	  
	  

	}
	
	

}
